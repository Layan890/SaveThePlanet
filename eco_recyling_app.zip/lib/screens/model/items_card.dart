class CardItem{
  final String icon;
  final String text;

  CardItem({required this.icon, required this.text});
}