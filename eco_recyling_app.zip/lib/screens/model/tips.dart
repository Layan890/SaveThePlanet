
class TipsDetail{

final int id;
 final String title;
 final String image;
 final String des;


  
 static List<TipsDetail> tips=[
    TipsDetail(id: 1, title: 'ECO Friendly ', image: 'assets/icons/eco_friendly.svg', 
    des:'ECO Friendly Literally Means Friendly to the Earth or simply not harmful to An Environment',
),
 TipsDetail(id: 2, title: 'UseFul Item ', image: 'assets/icons/earth-svgrepo-com.svg', 
    des:'A sustainable solution for a greener planet.\nDitch single-use plastic bags and embrace this reusable alternative.',
),
 TipsDetail(id: 2, title: 'Biadgradable ', image: 'assets/icons/earth-waste-svgrepo-com.svg', 
    des:'A sustainable solution for a greener planet.\nDitch single-use plastic bags and embrace this reusable alternative.',
),



  ];

  TipsDetail({required this.id, required this.title, required this.image, required this.des});

}

