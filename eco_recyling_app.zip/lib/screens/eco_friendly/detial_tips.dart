import 'package:eco_recyling_app/screens/model/tips.dart';
import 'package:eco_recyling_app/screens/root_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';

class DetailTips extends StatelessWidget {
  DetailTips({super.key, required this.tips_id});

  final int tips_id;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Save Planet Together'),
        centerTitle: true,
        backgroundColor: const Color(0xFF515c30),

        elevation: 0,
        toolbarHeight: 100, // Set the desired height of the AppBar
        leading: IconButton(
          onPressed: () {},
          icon: const Icon(Icons.arrow_back),
        ),
        actions: [
          IconButton(
            onPressed: () {},
            icon: const Icon(Icons.favorite),
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(200),
          child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(15),
                ),
                height: 200,
                width: 200,
                child: SizedBox(
                  child: SvgPicture.asset(TipsDetail.tips[tips_id].image),
                ),
              )),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              TipsDetail.tips[tips_id].title,
              style: const TextStyle(color: Colors.black, fontSize: 28),
            ),
            const SizedBox(
              height: 16,
            ),
            Text(
              TipsDetail.tips[tips_id].des,
              style: const TextStyle(
                  color: Colors.grey,
                  fontWeight: FontWeight.bold,
                  fontSize: 20),
            ),
            const SizedBox(
              height: 20,
            ),
            const Text(
              'Some Tips',
              style: TextStyle(
                  color: Colors.black,
                  fontWeight: FontWeight.bold,
                  fontSize: 20),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Container(
                    height: 40,
                    width: 30,
                    decoration: BoxDecoration(
                      color: const Color.fromARGB(255, 210, 207,
                          207), // Set the background color to light gray
                      shape: BoxShape.rectangle,
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: SvgPicture.asset('assets/icons/bag.svg'),
                  ),
                  const Padding(padding: EdgeInsets.symmetric(horizontal: 8)),
                  const Text(
                    'Use Biodgradable trash Bage',
                    style: TextStyle(
                        color: Colors.grey,
                        fontSize: 20,
                        fontStyle: FontStyle.italic),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Container(
                    height: 40,
                    width: 30,
                    decoration: BoxDecoration(
                      color: const Color.fromARGB(255, 210, 207,
                          207), // Set the background color to light gray
                      shape: BoxShape.rectangle,
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: SvgPicture.asset('assets/icons/bag.svg'),
                  ),
                  const Padding(padding: EdgeInsets.symmetric(horizontal: 8)),
                  const Text(
                    'Compastable cultery and bowls',
                    style: TextStyle(
                        color: Colors.grey,
                        fontSize: 20,
                        fontStyle: FontStyle.italic),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Container(
                    height: 40,
                    width: 30,
                    decoration: BoxDecoration(
                      color: const Color.fromARGB(255, 210, 207,
                          207), // Set the background color to light gray
                      shape: BoxShape.rectangle,
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: SvgPicture.asset('assets/icons/bag.svg'),
                  ),
                  const Padding(padding: EdgeInsets.symmetric(horizontal: 8)),
                  const Text(
                    'Get A safety razor  ',
                    style: TextStyle(
                        color: Colors.grey,
                        fontSize: 20,
                        fontStyle: FontStyle.italic),
                  ),
                ],
              ),
            ),
            Center(
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const RootPage(),
                    ),
                  );

                  // Add your button action here
                },
                style: ElevatedButton.styleFrom(
                    foregroundColor: const Color(0xFFE4D5B9),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 48, vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    backgroundColor: const Color(0xFF515c30)),
                child: const Text(
                  ' Go Tp Plants',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFFE4D5B9),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
